# Customer Churn Prediction

## Problem Statement
Predict whether a customer will churn based on historical data.

## Solution
Built a machine learning classification model using Logistic Regression.

## Tech Stack
Python, Pandas, NumPy, Scikit-learn

## Steps
- Data Cleaning
- Feature Encoding
- Model Training
- Evaluation

## Results
Basic working model demonstrating churn prediction.

## Future Improvements
- Use larger datasets
- Try advanced models
